# Amrita_Immersion_Batch_03
## Task-1 Creation of data set for Solar Panel Fault Detection
## Task-2 Gap Analysis on Map based Apps 
## Task-3 Design thinking for the capstone project 

