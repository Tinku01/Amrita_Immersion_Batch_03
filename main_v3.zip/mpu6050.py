# mpu6050.py
# Minimal MPU6050 driver for MicroPython
# Works with MPU6500 for accel + gyro

from machine import I2C
import math
import time

MPU6050_ADDR = 0x68

# MPU6050 Registers
PWR_MGMT_1 = 0x6B
ACCEL_XOUT_H = 0x3B
GYRO_XOUT_H = 0x43

class MPU6050:
    def __init__(self, i2c, addr=MPU6050_ADDR):
        self.i2c = i2c
        self.addr = addr
        # Wake up the sensor (clear sleep bit)
        self.i2c.writeto_mem(self.addr, PWR_MGMT_1, b'\x00')
        time.sleep(0.1)

    def read_raw_data(self, reg):
        high = self.i2c.readfrom_mem(self.addr, reg, 1)[0]
        low = self.i2c.readfrom_mem(self.addr, reg + 1, 1)[0]
        value = (high << 8) | low
        if value > 32767:
            value -= 65536
        return value

    def get_accel_data(self):
        ax = self.read_raw_data(ACCEL_XOUT_H) / 16384.0  # scale factor
        ay = self.read_raw_data(ACCEL_XOUT_H + 2) / 16384.0
        az = self.read_raw_data(ACCEL_XOUT_H + 4) / 16384.0
        return {'x': ax, 'y': ay, 'z': az}

    def get_gyro_data(self):
        gx = self.read_raw_data(GYRO_XOUT_H) / 131.0  # scale factor
        gy = self.read_raw_data(GYRO_XOUT_H + 2) / 131.0
        gz = self.read_raw_data(GYRO_XOUT_H + 4) / 131.0
        return {'x': gx, 'y': gy, 'z': gz}