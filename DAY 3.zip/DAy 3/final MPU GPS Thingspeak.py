import network
import urequests
import time
from machine import Pin, I2C, UART

# Wi-Fi credentials
SSID = "Tinku"
PASSWORD = "yobc2727"

# ThingSpeak API Key
THINGSPEAK_API_KEY = "57IQ5GOMXL9TUZXT"

# Connect to Wi-Fi
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASSWORD)
    while not wlan.isconnected():
        print("Connecting to WiFi...")
        time.sleep(1)
    print("Connected:", wlan.ifconfig())

# MPU6500 setup
i2c = I2C(0, scl=Pin(21), sda=Pin(20))
addr = 0x68
i2c.writeto_mem(addr, 0x6B, b'\x00')  # Wake up sensor
time.sleep(0.1)

def read_raw_data(reg):
    high, low = i2c.readfrom_mem(addr, reg, 2)
    value = (high << 8) | low
    if value > 32767:
        value -= 65536
    return value

# GPS setup on UART1 (TX=GPIO4, RX=GPIO5)
uart = UART(1, baudrate=9600, tx=Pin(4), rx=Pin(5))

def convert_to_decimal(coord, direction):
    if coord == '':
        return None
    try:
        degrees = int(coord[:2])
        minutes = float(coord[2:])
        decimal = degrees + minutes / 60
        if direction in ['S', 'W']:
            decimal = -decimal
        return decimal
    except:
        return None

def parse_gpgga(sentence):
    parts = sentence.split(',')
    if parts[0] == "$GPGGA" and len(parts) > 5:
        lat = convert_to_decimal(parts[2], parts[3])
        lon = convert_to_decimal(parts[4], parts[5])
        return lat, lon
    return None, None

def get_gps():
    if uart.any():
        try:
            line = uart.readline().decode('utf-8').strip()
            if line.startswith('$GPGGA'):
                return parse_gpgga(line)
        except:
            pass
    return None, None

# Main Loop
connect_wifi()
while True:
    # MPU6500 readings
    acc_x = read_raw_data(0x3B)
    acc_y = read_raw_data(0x3D)
    acc_z = read_raw_data(0x3F)
    gyro_x = read_raw_data(0x43)
    gyro_y = read_raw_data(0x45)
    gyro_z = read_raw_data(0x47)

    ax = acc_x / 16384.0
    ay = acc_y / 16384.0
    az = acc_z / 16384.0
    gx = gyro_x / 131.0
    gy = gyro_y / 131.0
    gz = gyro_z / 131.0

    lat, lon = get_gps()

    print("Accel: {:.2f}, {:.2f}, {:.2f} | Gyro: {:.2f}, {:.2f}, {:.2f}".format(ax, ay, az, gx, gy, gz))
    if lat and lon:
        print("GPS → Latitude: {:.6f}, Longitude: {:.6f}".format(lat, lon))
    else:
        print("GPS data invalid or not found")

    # Send to ThingSpeak
    try:
        url = "https://api.thingspeak.com/update?api_key={}&field1={}&field2={}&field3={}&field4={}&field5={}&field6={}&field7={}&field8={}".format(
            THINGSPEAK_API_KEY, ax, ay, az, gx, gy, gz, lat or 0, lon or 0)
        response = urequests.get(url)
        print("ThingSpeak response:", response.text)
        response.close()
    except Exception as e:
        print("Error sending to ThingSpeak:", e)

    time.sleep(15)  # ThingSpeak allows update every 15 sec
